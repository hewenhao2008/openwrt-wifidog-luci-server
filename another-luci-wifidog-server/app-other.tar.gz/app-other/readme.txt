trunk版本：
将luci-app-other目录放到./feeds/luci/applications/目录下。
然后源码根目录下执行：
./scripts/feeds update -i
./scripts/feeds install -a

然后 make menuconfig在luci-->Applications下找到luci-app-other选上。

make package/feeds/luci/luci/compile V=s
